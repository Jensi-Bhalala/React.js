import 'bootstrap/dist/css/bootstrap.min.css'
import Data from './pages/Contact'

function App() {
    return(
      <>
      <Data/>
      </>
    )
}
export default Data