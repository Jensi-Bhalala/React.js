
import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyDm0aTeDFCFXrZ3TAVu0Ewq7c-umS47lLw",
  authDomain: "fir-realtime-database-4d018.firebaseapp.com",
  projectId: "fir-realtime-database-4d018",
  storageBucket: "fir-realtime-database-4d018.firebasestorage.app",
  messagingSenderId: "24129822464",
  appId: "1:24129822464:web:f15899dc21d6d01fd8dde5",
  measurementId: "G-R9LHNDMPBH"
};

export const app = initializeApp(firebaseConfig);
