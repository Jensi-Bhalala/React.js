import React from "react";
import Header from "../../components/Header";

const Product = () => {
  return (
    <>
      <Header />
      <div className="mt-5">
        <h1>Product Page</h1>
      </div>
    </>
  );
};

export default Product;
