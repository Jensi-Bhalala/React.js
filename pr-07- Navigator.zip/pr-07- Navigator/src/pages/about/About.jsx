import React from 'react'
import Header from '../../components/Header'

const About = () => {
  return (
    <>
      <Header/>
      <div className='mt-5'>
       <h1>About Page</h1>
      </div>
    </>
  )
}

export default About
