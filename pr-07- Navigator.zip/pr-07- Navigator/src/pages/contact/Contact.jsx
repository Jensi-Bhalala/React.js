import React from "react";
import Header from "../../components/Header";

const Contact = () => {
  return (
    <>
      <Header />
      <div className="mt-5">
        <h1>Contact Page</h1>
      </div>
    </>
  );
};

export default Contact;
